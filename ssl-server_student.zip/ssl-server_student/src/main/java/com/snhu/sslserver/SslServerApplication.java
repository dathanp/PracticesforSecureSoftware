package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController{
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name.    
    @GetMapping("/hash")
    public String myHash(){
    	String data = "Dathan Pompa Check Sum";
    	String algorithm = "SHA-256";
    	String checkSum = generateCheckSum(data, algorithm);
    	return "<p>data:"+data+ "\n" + algorithm+ "Algorithm Cipher: CheckSum Value:" + checkSum;
    }
    
    
    private String generateCheckSum(String data, String algorithm) {
    	try {
        	// create object of message digest class from java.security library
    		MessageDigest digest = MessageDigest.getInstance("SHA-256");
    		//hash value
    		byte[] hash = digest.digest(data.getBytes());
    		// converts hash to hex
    		String hex = bytesToHex(hash);
    		return hex;
    		
    	} catch (NoSuchAlgorithmException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    		return e.getMessage();
    		}
    }
    
    
    private static String bytesToHex(byte[] byteArray) {
    	StringBuilder sb = new StringBuilder();
    	for(byte b : byteArray) {
    		sb.append(String.format("%02X",b));
    	}
    	return sb.toString();
    }
    
}

